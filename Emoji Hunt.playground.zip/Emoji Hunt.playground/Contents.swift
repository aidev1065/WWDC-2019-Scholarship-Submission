/*:
 # Emoji Hunt
 ## Do you have what it takes to master the digital and physical world?
Technology, for all its exceptionality, has lead us to a certain disconnect from the real world.

With Augmented Reality, our reality has been given another chance, giving us the power to notice details we would not have previously.

With our strange, but wonderful, addiction to emojis, we love seeing these delightful hieroglyphics on our screens. But what about the real world?It's time for a hunt!

A hunt to find the modern hieroglyphics in the real world, stay connected with your surroundings, encourage digital wellbeing, and prove that you are truly the human form of the 💯 emoji!
 
Run the playground to start!
 */

//#-hidden-code
import UIKit
import Vision
import CoreML
import PlaygroundSupport
import ARKit
import SceneKit
import Foundation
import AVKit

var currentAvatar = ""
var finalScore = 0
var won = false

class HomeViewController: UIViewController {
    let titleLabel = createTitle(title: "Emoji Hunt", textColor: #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0), fontSize: 50, alignment: .center, solid: false)
    let playButton = createButton(title: "🕹 Play", bgColor: #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0), fontColor: .white)
    let aboutButton = createButton(title: "🌟 About", bgColor: #colorLiteral(red: 0.0, green: 0.91, blue: 0.945, alpha: 1.0), fontColor: .white)
    let audioButton = createButton(title: "🎵 Music: On", bgColor: #colorLiteral(red: 0.0, green: 0.91, blue: 0.945, alpha: 1.0), fontColor: .white)
    let darkButton = createButton(title: "🌌 Dark Mode: Off", bgColor: #colorLiteral(red: 0.0, green: 0.91, blue: 0.945, alpha: 1.0), fontColor: .white)
    let logo = createImageView()
    var soundtrack: AVAudioPlayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = #colorLiteral(red: 0.98039215686, green: 0.98039215686, blue: 0.98039215686, alpha: 1.0)
        view.addSubview(titleLabel)
        
        logo.image = #imageLiteral(resourceName: "Artboard.png")
        view.addSubview(logo)
        
        playButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
        playButton.layer.shadowOpacity = 0.2
        playButton.layer.shadowOffset = CGSize(width: 0, height: 10)
        playButton.layer.shadowRadius = 10
        playButton.layer.masksToBounds = false
        playButton.layer.cornerRadius = 10
        aboutButton.layer.cornerRadius = 8
        audioButton.layer.cornerRadius = 8
        darkButton.layer.cornerRadius = 8
        
        self.aboutButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
        self.aboutButton.layer.shadowOpacity = 0.2
        self.aboutButton.layer.shadowRadius = 10
        self.aboutButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.aboutButton.layer.masksToBounds = false
        self.audioButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
        self.audioButton.layer.shadowOpacity = 0.2
        self.audioButton.layer.shadowRadius = 10
        self.audioButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.audioButton.layer.masksToBounds = false
        self.darkButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
        self.darkButton.layer.shadowOpacity = 0.2
        self.darkButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.darkButton.layer.shadowRadius = 10
        self.darkButton.layer.masksToBounds = false
        view.addSubview(playButton)
        view.addSubview(aboutButton)
        view.addSubview(audioButton)
        view.addSubview(darkButton)
        playButton.addTarget(self, action: #selector(self.playGame(sender:)), for: .touchUpInside)
        aboutButton.addTarget(self, action: #selector(self.showAbout(sender:)), for: .touchUpInside)
        audioButton.addTarget(self, action: #selector(self.controlAudio(sender:)), for: .touchUpInside)
        darkButton.addTarget(self, action: #selector(self.switchTheme(sender:)), for: .touchUpInside)
        
        titleLabel.alpha = 0
        logo.alpha = 0
        playButton.alpha = 0
        aboutButton.alpha = 0
        audioButton.alpha = 0
        darkButton.alpha = 0
        
        UserDefaults.standard.set(nil, forKey: "darkModeOn")
        UserDefaults.standard.set(nil, forKey: "playedOnce")
        
        let path = Bundle.main.path(forResource: "Shut The Front Door.m4a", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        do {
            soundtrack = try AVAudioPlayer(contentsOf: url)
            soundtrack?.numberOfLoops = 10
            soundtrack?.volume = 0.1
            soundtrack?.play()
            
            let topAnimator = UIViewPropertyAnimator(duration: 0.5, dampingRatio: 1.0) {
                self.logo.alpha = 1.0
                self.logo.frame = self.logo.frame.offsetBy(dx: 0, dy: 125)
                self.titleLabel.alpha = 1.0
                self.titleLabel.frame = self.titleLabel.frame.offsetBy(dx: 0, dy: 145)
            }
            
            let buttonAnimator = UIViewPropertyAnimator(duration: 0.5, dampingRatio: 1.0) {
                self.playButton.alpha = 1.0
                self.playButton.frame = self.playButton.frame.offsetBy(dx: 0, dy: ((self.view.frame.height / 2) - (self.titleLabel.frame.minY)))
                self.aboutButton.alpha = 1.0
                self.aboutButton.frame = self.aboutButton.frame.offsetBy(dx: 0, dy: 182)
                self.audioButton.alpha = 1.0
                self.audioButton.frame = self.audioButton.frame.offsetBy(dx: 0, dy: 182)
                self.darkButton.alpha = 1.0
                self.darkButton.frame = self.darkButton.frame.offsetBy(dx: 0, dy: 182)
            }
            topAnimator.startAnimation(afterDelay: 1.25)
            buttonAnimator.startAnimation(afterDelay: 1.5)
        } catch {
            print("Uh-oh")
        }
    }
    
    @objc func playGame(sender: UIButton!) {
        if UserDefaults.standard.bool(forKey: "playedOnce") {
            let alert = UIAlertController(title: "Take a break!", message: "In the real game, you can interact only a few times per hour because the main goal is to have you connected with the real world. Look up and take a break. When you're ready, jump back in. You can restart the playground if you feel the need to play more!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK!", style: .default, handler: { (action) in
                
            }))
            self.present(alert, animated: true, completion: nil)
        } else {
            let vc = GameViewController()
            UserDefaults.standard.set(true, forKey: "playedOnce")
            vc.modalTransitionStyle = .crossDissolve
            present(vc, animated: true, completion: nil)
        }
    }
    
    @objc func showAbout(sender: UIButton!) {
        if won == true {
            let alert = UIAlertController(title: "Take a break!", message: "In the real game, you can interact only a few times per hour because the main goal is to have you connected with the real world. Look up and take a break. When you're ready, jump back in. You can restart the playground if you feel the need to play more!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK!", style: .default, handler: { (action) in
                
            }))
            DispatchQueue.main.async {
                self.present(alert, animated: true, completion: nil)
            }
        } else {
            DispatchQueue.main.async {
                let vc = AboutViewController()
                vc.modalTransitionStyle = .flipHorizontal
                self.present(vc, animated: true, completion: nil)
            }
        }
    }
    
    @objc func controlAudio(sender: UIButton!) {
        if audioButton.titleLabel?.text == "🎵 Music: On" {
            audioButton.setTitle("🎵 Music: Off", for: .normal)
            soundtrack?.volume = 0
        } else {
            audioButton.setTitle("🎵 Music: On", for: .normal)
            soundtrack?.volume = 0.1
        }
    }
    
    @objc func switchTheme(sender: UIButton!) {
        if won == true {
            let alert = UIAlertController(title: "Take a break!", message: "In the real game, you can interact only a few times per hour because the main goal is to have you connected with the real world. Look up and take a break. When you're ready, jump back in. You can restart the playground if you feel the need to play more!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK!", style: .default, handler: { (action) in
                
            }))
            DispatchQueue.main.async {
                self.present(alert, animated: true, completion: nil)
            }
        } else {
            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut, animations: {
                    if (self.darkButton.titleLabel?.text?.lowercased().contains("off"))! {
                        UserDefaults.standard.set(true, forKey: "darkModeOn")
                        self.darkButton.setTitle("🌌 Dark Mode: On", for: .normal)
                        self.titleLabel.textColor = #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0)
                        self.playButton.backgroundColor = #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0)
                        self.aboutButton.backgroundColor = #colorLiteral(red: 0.1764705926179886, green: 0.49803921580314636, blue: 0.7568627595901489, alpha: 1.0)
                        self.audioButton.backgroundColor = #colorLiteral(red: 0.1764705926179886, green: 0.49803921580314636, blue: 0.7568627595901489, alpha: 1.0)
                        self.darkButton.backgroundColor = #colorLiteral(red: 0.1764705926179886, green: 0.49803921580314636, blue: 0.7568627595901489, alpha: 1.0)
                        
                        self.playButton.layer.shadowColor = #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0).cgColor
                        self.playButton.layer.shadowOpacity = 0.3
                        self.playButton.layer.shadowRadius = 5
                        self.playButton.layer.masksToBounds = false
                        
                        let gradient = createGradient(colors: [#colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor, #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
                        gradient.frame = self.view.bounds
                        self.view.layer.insertSublayer(gradient, below: self.titleLabel.layer)
                    } else {
                        UserDefaults.standard.set(false, forKey: "darkModeOn")
                        self.darkButton.setTitle("🌌 Dark Mode: Off", for: .normal)
                        self.titleLabel.textColor = #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0)
                        self.playButton.backgroundColor = #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0)
                        self.aboutButton.backgroundColor = #colorLiteral(red: 0.0, green: 0.91, blue: 0.945, alpha: 1.0)
                        self.audioButton.backgroundColor = #colorLiteral(red: 0.0, green: 0.91, blue: 0.945, alpha: 1.0)
                        self.darkButton.backgroundColor = #colorLiteral(red: 0.0, green: 0.91, blue: 0.945, alpha: 1.0)
                        
                        self.playButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
                        self.playButton.layer.shadowOpacity = 0.2
                        self.playButton.layer.shadowOffset = CGSize(width: 0, height: 10)
                        self.playButton.layer.shadowRadius = 10
                        self.playButton.layer.masksToBounds = false
                        
                        let gradient = createGradient(colors: [#colorLiteral(red: 0.9607843137, green: 0.968627451, blue: 0.9803921569, alpha: 1).cgColor, #colorLiteral(red: 0.7215686275, green: 0.8117647059, blue: 0.8588235294, alpha: 1).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
                        gradient.frame = self.view.bounds
                        self.view.layer.insertSublayer(gradient, below: self.titleLabel.layer)
                    }
                }, completion: nil)
            }
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        logo.frame = CGRect(x: self.view.frame.midX - 75, y: 0, width: 150, height: 150)
        titleLabel.frame = CGRect(x: 24, y: self.logo.frame.maxY - 20, width: self.view.frame.width - 48, height: 66)
        playButton.frame = CGRect(x: self.view.frame.midX - 150, y: self.view.frame.midY - 30, width: 300, height: 80)
        darkButton.frame = CGRect(x: self.view.frame.midX - 125, y: self.view.frame.maxY - 66, width: 250, height: 50)
        audioButton.frame = CGRect(x: self.view.frame.midX - 125, y: self.darkButton.frame.minY - 66, width: 250, height: 50)
        aboutButton.frame = CGRect(x: self.view.frame.midX - 125, y: self.audioButton.frame.minY - 66, width: 250, height: 50)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIView.animate(withDuration: 1.0, delay: 0.0, options: [.autoreverse, .repeat, .allowUserInteraction], animations: {
            self.playButton.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }, completion: nil)
        let gradient = createGradient(colors: [#colorLiteral(red: 0.961, green: 0.969, blue: 0.98, alpha: 1).cgColor, #colorLiteral(red: 0.722, green: 0.812, blue: 0.859, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
        gradient.frame = self.view.bounds
        self.view.layer.insertSublayer(gradient, at: 0)
    }
}

class AvatarViewController: UIViewController, ARSCNViewDelegate {
    let avatarLabel = createTitle(title: "Create your avatar!", textColor: #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0), fontSize: 50, alignment: .center, solid: false)
    let descLabel = createLabel(title: "Smile and create your emoji avatar!", textColor: #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0), fontSize: 25, fontWeight: .semibold, alignment: .center)
    let sceneView = ARSCNView(frame: .zero)
    let snapButton = createButton(title: "Snap!", bgColor: #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0), fontColor: .white)
    let rulesLabel = createLabel(title: "Here are the rules. You have 20 seconds to find 3 emojis given to you. Each emoji you find adds 5 seconds to the timer. The faster you find the emojis in real life, the higher you score. Tap the button when you are ready!", textColor: #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0), fontSize: 20, fontWeight: .semibold, alignment: .center)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            self.sceneView.delegate = self
        
            self.view.addSubview(self.avatarLabel)
            self.view.addSubview(self.descLabel)
            self.view.addSubview(self.sceneView)
            self.view.addSubview(self.snapButton)
            self.view.addSubview(self.rulesLabel)
        
            self.avatarLabel.translatesAutoresizingMaskIntoConstraints = false
            self.avatarLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 24).isActive = true
            self.avatarLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0).isActive = true
            self.avatarLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0).isActive = true
            self.avatarLabel.heightAnchor.constraint(equalToConstant: 70).isActive = true
        
            self.descLabel.translatesAutoresizingMaskIntoConstraints = false
            self.descLabel.topAnchor.constraint(equalTo: self.avatarLabel.bottomAnchor, constant: 16).isActive = true
            self.descLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 8).isActive = true
            self.descLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -8).isActive = true
            self.descLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
            self.sceneView.translatesAutoresizingMaskIntoConstraints = false
            self.sceneView.topAnchor.constraint(equalTo: self.descLabel.bottomAnchor, constant: 16).isActive = true
            self.sceneView.leadingAnchor.constraint(equalTo: self.view.centerXAnchor, constant: -100).isActive = true
            self.sceneView.widthAnchor.constraint(equalToConstant: 200).isActive = true
            self.sceneView.heightAnchor.constraint(equalToConstant: 200).isActive = true
            self.sceneView.layer.cornerRadius = 100
            self.sceneView.layer.masksToBounds = true
        
            self.snapButton.translatesAutoresizingMaskIntoConstraints = false
            self.snapButton.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -24).isActive = true
            self.snapButton.leadingAnchor.constraint(equalTo: self.view.centerXAnchor, constant: -150).isActive = true
            self.snapButton.widthAnchor.constraint(equalToConstant: 300).isActive = true
            self.snapButton.heightAnchor.constraint(equalToConstant: 60).isActive = true
            self.snapButton.addTarget(self, action: #selector(self.analyzeAvatar), for: .touchUpInside)
            self.snapButton.layer.cornerRadius = 8
            self.snapButton.layer.masksToBounds = true
        
            self.rulesLabel.translatesAutoresizingMaskIntoConstraints = false
            self.rulesLabel.topAnchor.constraint(equalTo: self.sceneView.bottomAnchor, constant: 16).isActive = true
            self.rulesLabel.bottomAnchor.constraint(equalTo: self.snapButton.topAnchor, constant: -16).isActive = true
            self.rulesLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 16).isActive = true
            self.rulesLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -16).isActive = true
            self.rulesLabel.numberOfLines = 0
            self.rulesLabel.alpha = 0
            
            if UserDefaults.standard.bool(forKey: "darkModeOn") {
                let gradient = createGradient(colors: [#colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor, #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
                gradient.frame = self.view.bounds
                self.view.layer.insertSublayer(gradient, below: self.avatarLabel.layer)
                self.avatarLabel.textColor = #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0)
                self.descLabel.textColor = .white
                self.snapButton.backgroundColor = #colorLiteral(red: 0.1764705926179886, green: 0.49803921580314636, blue: 0.7568627595901489, alpha: 1.0)
                self.rulesLabel.textColor = .white
                
                self.snapButton.layer.shadowColor = #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0).cgColor
                self.snapButton.layer.shadowOpacity = 0.3
                self.snapButton.layer.shadowRadius = 5
                self.snapButton.layer.masksToBounds = false
            } else {
                let gradient = createGradient(colors: [#colorLiteral(red: 0.961, green: 0.969, blue: 0.98, alpha: 1).cgColor, #colorLiteral(red: 0.722, green: 0.812, blue: 0.859, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
                gradient.frame = self.view.bounds
                self.view.layer.insertSublayer(gradient, below: self.avatarLabel.layer)
                self.snapButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
                self.snapButton.layer.shadowOpacity = 0.2
                self.snapButton.layer.shadowRadius = 10
                self.snapButton.layer.shadowOffset = CGSize(width: 0, height: 10)
                self.snapButton.layer.masksToBounds = false
            }
        }
    }
    
    @objc func analyzeAvatar() {
        if self.avatarLabel.text == "Create your avatar!" {
            if let currentFrame = sceneView.session.currentFrame {
                DispatchQueue.global(qos: .background).async {
                    do {
                        let model = try? VNCoreMLModel(for: GenderClassifier().model)
                        let request = VNCoreMLRequest(model: model!, completionHandler: { (request, error) in
                            DispatchQueue.main.async {
                                guard let results = request.results as? [VNClassificationObservation], let result = results.first else { return }
                                if result.identifier == "Male" {
                                    UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut, animations: { 
                                        self.avatarLabel.text = "🕵️‍♂️ Mr. Detective"
                                    }, completion: nil)
                                    currentAvatar = "🕵️‍♂️"
                                } else {
                                    UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut, animations: { 
                                        self.avatarLabel.text = "🕵️‍♀️ Ms. Detective"
                                    }, completion: nil)
                                    currentAvatar = "🕵️‍♀️"
                                }
                                UIView.animate(withDuration: 0.25, delay: 0, options: .curveEaseInOut, animations: { 
                                    self.descLabel.text = "Your avatar has been created!"
                                    self.snapButton.setTitle("Start Game!", for: .normal)
                                    self.rulesLabel.alpha = 1.0
                                }, completion: nil)
                            }
                        })
                        let handler = VNImageRequestHandler(cvPixelBuffer: currentFrame.capturedImage, options: [:])
                        try handler.perform([request])
                    } catch {}
                }
            }
        } else {
            let vc = GameViewController()
            vc.startGame()
            NotificationCenter.default.post(name: NSNotification.Name("startGame"), object: nil)
            dismiss(animated: true, completion: nil)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if ARFaceTrackingConfiguration.isSupported {
            sceneView.session.run(ARFaceTrackingConfiguration())
        } else {
            sceneView.session.run(ARWorldTrackingConfiguration())
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
}

class GameViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate {
    var emojiArray = ["📚", "🚗", "🐶", "🐱", "⌚️", "🌲", "💻", "🍎", "🍌", "☁️", "🌺", "🌭", "📱", "👕", "👟"]
    let titleLabel = createTitle(title: "Loading...", textColor: #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0), fontSize: 30, alignment: .center, solid: true)
    let scoreView = UILabel()
    let timerLabel = createTitle(title: "20", textColor: #colorLiteral(red: 0.69, green: 0.745, blue: 0.773, alpha: 1.0), fontSize: 25, alignment: .right, solid: true)
    let timerImage = createImageView()
    var sceneView = ARSCNView(frame: .zero)
    let pointerButton = createButton(title: "👆", bgColor: #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 0.85), fontColor: .black)
    var runAnimation = true
    
    var seconds = 20
    var emojiToFind: String!
    var currentScore = 0
    let session = ARSession()
    var foundEmojis: [String] = []
    
    override func loadView() {
        super.loadView()
        let view = UIView()
        view.backgroundColor = #colorLiteral(red: 0.96078431372, green: 0.96078431372, blue: 0.96078431372, alpha: 1.0)
        scoreView.font = UIFont(name: "Phosphate-Solid", size: 24)
        scoreView.textColor = .white
        scoreView.textAlignment = .center
        
        view.addSubview(titleLabel)
        view.addSubview(scoreView)
        view.addSubview(timerLabel)
        view.addSubview(sceneView)
        view.addSubview(timerImage)
        view.addSubview(pointerButton)
        
        self.view = view
        scoreView.layer.cornerRadius = 25
        scoreView.layer.masksToBounds = true
        
        timerImage.contentMode = .scaleAspectFit
        timerImage.image = #imageLiteral(resourceName: "Timer.png")
        
        pointerButton.layer.cornerRadius = 40
        pointerButton.layer.masksToBounds = true
        pointerButton.titleLabel?.font = UIFont(name: "Phosphate-Solid", size: 50)
        pointerButton.addTarget(self, action: #selector(self.recognizeEmojis), for: .touchUpInside)
        pointerButton.showsTouchWhenHighlighted = true
        
        // Layout
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        scoreView.translatesAutoresizingMaskIntoConstraints = false
        timerLabel.translatesAutoresizingMaskIntoConstraints = false
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        timerImage.translatesAutoresizingMaskIntoConstraints = false
        pointerButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 24),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0),
            titleLabel.heightAnchor.constraint(equalToConstant: 50),
            scoreView.topAnchor.constraint(equalTo: view.topAnchor, constant: 24),
            scoreView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            scoreView.widthAnchor.constraint(equalToConstant: 125),
            scoreView.heightAnchor.constraint(equalToConstant: 50),
            timerLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 24),
            timerLabel.widthAnchor.constraint(equalToConstant: 50),
            timerLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            timerLabel.heightAnchor.constraint(equalToConstant: 50),
            timerImage.topAnchor.constraint(equalTo: view.topAnchor, constant: 34.5),
            timerImage.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -55),
            timerImage.heightAnchor.constraint(equalToConstant: 30),
            timerImage.widthAnchor.constraint(equalToConstant: 30),
            sceneView.topAnchor.constraint(equalTo: scoreView.bottomAnchor, constant: 24),
            sceneView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            sceneView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0),
            sceneView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0),
            pointerButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -24),
            pointerButton.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant: 40),
            pointerButton.heightAnchor.constraint(equalToConstant: 80),
            pointerButton.widthAnchor.constraint(equalToConstant: 80)
            ])
        
        let scene = SCNScene()
        sceneView.scene = scene
        sceneView.delegate = self
        sceneView.setup()
        sceneView.session = session
        sceneView.showsStatistics = false
        sceneView.session.delegate = self
        sceneView.autoenablesDefaultLighting = true
        sceneView.automaticallyUpdatesLighting = true
        
        if UserDefaults.standard.bool(forKey: "darkModeOn") {
            view.backgroundColor = #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0)
            titleLabel.textColor = #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0)
            pointerButton.backgroundColor = #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0)
            scoreView.backgroundColor = #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0)
        } else {
            view.backgroundColor = #colorLiteral(red: 0.98039215686, green: 0.98039215686, blue: 0.98039215686, alpha: 1.0)
            titleLabel.textColor = #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0)
            pointerButton.backgroundColor = #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0)
            scoreView.backgroundColor = #colorLiteral(red: 0.161, green: 0.475, blue: 1.0, alpha: 1.0)
        }
    }
    
    @objc func startGame() {
        DispatchQueue.main.async {
            self.randomEmoji()
            self.runTimer(stop: false)
            self.scoreView.text = "\(currentAvatar) \(self.currentScore)"
            let configuration = ARWorldTrackingConfiguration()
            configuration.planeDetection = .horizontal
            self.sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.startGame), name: NSNotification.Name("startGame"), object: nil)
        let vc = AvatarViewController()
        vc.modalPresentationStyle = .formSheet
        vc.modalTransitionStyle = .coverVertical
        self.present(vc, animated: true, completion: nil)
    }
    
    func randomEmoji() {
        if emojiArray.count != 0 {
            let randomIndex = Int(arc4random_uniform(UInt32(emojiArray.count)))
            emojiToFind = emojiArray[randomIndex]
            emojiArray.remove(at: randomIndex)
            titleLabel.text = "Find \(emojiToFind!)"
        }
    }
    
    func runTimer(stop: Bool) {
        let timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateTimer), userInfo: nil, repeats: true)
        if stop == true {
            timer.invalidate()
        }
    }
    
    @objc func updateTimer() {
        if !runAnimation { return }
        if seconds == 0 || self.foundEmojis.count == 3 {
            self.pointerButton.removeTarget(nil, action: nil, for: .allEvents)
            self.pointerButton.isEnabled = false
            timerLabel.text = "0"
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseInOut, animations: { 
                if self.foundEmojis.count > 4 {
                    // RUN THROUGH SOMETHING
                } else if self.foundEmojis.count == 3 {
                    finalScore = self.currentScore + 100
                    self.scoreView.text = "\(currentAvatar) \(finalScore)"
                    self.titleLabel.text = "You won!"
                    won = true
                } else if self.foundEmojis.count < 3 {
                    finalScore = self.currentScore
                    self.scoreView.text = "\(currentAvatar) \(finalScore)"
                    self.titleLabel.text = "You Lost!"
                    won = false
                }
                self.foundEmojis.append("sdf")
                self.pointerButton.isEnabled = true
                self.pointerButton.titleLabel?.text = "🏠"
                self.pointerButton.addTarget(self, action: #selector(self.goHome), for: .touchUpInside)
            }, completion: { (true) in
                self.seconds -= 1
                DispatchQueue.main.async {
                    self.runTimer(stop: true)
                }
            })
        } else if seconds > 5 && self.foundEmojis.count < 4 {
            timerLabel.textColor = #colorLiteral(red: 0.69, green: 0.745, blue: 0.773, alpha: 1.0)
            timerLabel.text = "\(seconds)"
            seconds -= 1
        } else if seconds <= 5 && self.foundEmojis.count < 4 && seconds > 0 {
            timerLabel.text = "\(seconds)"
            timerLabel.textColor = #colorLiteral(red: 0.8745098039, green: 0, blue: 0.07058823529, alpha: 1)
            seconds -= 1
        }
    }
    
    @objc func goHome() {
        DispatchQueue.main.async {
            self.dismiss(animated: true, completion: { 
                self.runAnimation = false
            })
        }
    }
    
    func recognizedEmoji(emoji: String) {
        foundEmojis.append(emoji)
        self.currentScore += self.seconds
        self.scoreView.text = "\(currentAvatar) \(self.currentScore)"
        self.seconds += 5
        let currentFrame = self.sceneView.session.currentFrame 
        let skScene = SKScene(size: CGSize(width: 200, height: 200))
        skScene.backgroundColor = UIColor.clear
        let labelNode = SKLabelNode(text: emoji)
        labelNode.fontSize = 100
        labelNode.fontName = "Phosphate-Solid"
        labelNode.position = CGPoint(x:100,y:100)
        labelNode.zRotation = .pi
        skScene.addChild(labelNode)
            
        var translation = matrix_identity_float4x4
        let plane = SCNPlane(width: 0.1, height: 0.075)
        let material = SCNMaterial()
        material.isDoubleSided = true
        material.diffuse.contents = skScene
        material.lightingModel = .constant
        plane.materials = [material]
        translation.columns.3.z = -0.15
        let node = SCNNode(geometry: plane)
        node.simdTransform = matrix_multiply((currentFrame!.camera.transform), translation)
        self.sceneView.scene.rootNode.addChildNode(node)
    }
    
    @objc func recognizeEmojis() {
        if let currentFrame = sceneView.session.currentFrame {
            do {
                let model = try? VNCoreMLModel(for: EmojiIRL().model)
                let request = VNCoreMLRequest(model: model!, completionHandler: { (request, error) in
                        guard let results = request.results as? [VNClassificationObservation], let result  = results.first else {
                            print("No Results?")
                            return
                        }
                        if result.identifier == "Apple" && self.emojiToFind == "🍎" {
                            if let index = self.emojiArray.index(of: "🍎") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "🍎")
                            }
                        } else if result.identifier == "Banana" && self.emojiToFind == "🍌" {
                            if let index = self.emojiArray.index(of: "🍌") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "🍌")
                            }
                        } else if result.identifier == "Book" && self.emojiToFind == "📚" {
                            if let index = self.emojiArray.index(of: "📚") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "📚")
                            }
                        } else if result.identifier == "Car" && self.emojiToFind == "🚗" {
                            if let index = self.emojiArray.index(of: "🚗") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "🚗")
                            }
                        } else if result.identifier == "Cat" && self.emojiToFind == "🐱" {
                            if let index = self.emojiArray.index(of: "🐱") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "🐱")
                            }
                        } else if result.identifier == "Cloud" && self.emojiToFind == "☁️" {
                            if let index = self.emojiArray.index(of: "☁️") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "☁️")
                            }
                        } else if result.identifier == "Dog" && self.emojiToFind == "🐶" {
                            if let index = self.emojiArray.index(of: "🐶") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "🐶")
                            }
                        } else if result.identifier == "Flower" && self.emojiToFind == "🌺" {
                            if let index = self.emojiArray.index(of: "🌺") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "🌺")
                            }
                        } else if result.identifier == "Hot Dog" && self.emojiToFind == "🌭" {
                            if let index = self.emojiArray.index(of: "🌭") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "🌭")
                            }
                        } else if result.identifier == "Laptop" && self.emojiToFind == "💻" {
                            if let index = self.emojiArray.index(of: "💻") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "💻")
                            }
                        } else if result.identifier == "Phone" && self.emojiToFind == "📱" {
                            if let index = self.emojiArray.index(of: "📱") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "📱")
                            }
                        } else if result.identifier == "Shirt" && self.emojiToFind == "👕" {
                            if let index = self.emojiArray.index(of: "👕") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "👕")
                            }
                        } else if result.identifier == "Shoes" && self.emojiToFind == "👟" {
                            if let index = self.emojiArray.index(of: "👟") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "👟")
                            }
                        } else if result.identifier == "Tree" && self.emojiToFind == "🌲" {
                            if let index = self.emojiArray.index(of: "🌲") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "🌲")
                            }
                        } else if result.identifier == "Watch" && self.emojiToFind == "⌚️" {
                            if let index = self.emojiArray.index(of: "⌚️") {
                                self.emojiArray.remove(at: index)
                            }
                            self.emojiToFind = self.emojiArray.randomElement()
                            self.titleLabel.text = "Find \(self.emojiToFind!)"
                            DispatchQueue.main.async {
                                self.recognizedEmoji(emoji: "⌚️")
                            }
                        } 
                })
                let handler = VNImageRequestHandler(cvPixelBuffer: currentFrame.capturedImage,  options:  [:])
                try handler.perform([request])
            } catch {}
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.sceneView.session.pause()
    }
}

class AboutViewController: UIViewController {
    let dismissButton = UIButton(frame: .zero)
    let titleLabel = UILabel(frame: .zero)
    let descLabel = createLabel(title: "Welcome to the About page! Take a look and tap around to see some of my projects or the workings of this playground. Before you start exploring, I want to acknowledge my family for encouraging me everyday. Next, I want to thank all the amazing people at Apple for giving me this opportunity to showcase my talents! Thank you! Hope you enjoy my playground!", textColor: .white, fontSize: 17, fontWeight: .medium, alignment: .center)
    let viewsButton = createButton(title: "The Views News", bgColor: #colorLiteral(red: 0.364705890417099, green: 0.06666667014360428, blue: 0.9686274528503418, alpha: 1.0), fontColor: .white)
    let mmlButton = createButton(title: "Mastering Machine Learning for iOS", bgColor: #colorLiteral(red: 0.8549019694328308, green: 0.250980406999588, blue: 0.47843137383461, alpha: 1.0), fontColor: .white)
    let retinaButton = createButton(title: "Retina AI", bgColor: #colorLiteral(red: 0.4745098054409027, green: 0.8392156958580017, blue: 0.9764705896377563, alpha: 1.0), fontColor: .white)
    let playgroundsButton = createButton(title: "Emoji Hunt", bgColor: #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0), fontColor: .white)
    
    override func loadView() {
        super.loadView()
        dismissButton.layer.cornerRadius = 10
        dismissButton.layer.masksToBounds = true
        dismissButton.backgroundColor = .white
        dismissButton.setTitle("Go Back!", for: .normal)
        dismissButton.titleLabel?.font = UIFont(name: "Phosphate-Solid", size: 24)
        dismissButton.addTarget(self, action: #selector(self.goBack), for: .touchUpInside)
        
        titleLabel.text = "About"
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont(name: "Phosphate-Inline", size: 40)
        DispatchQueue.main.async {
            self.view.addSubview(self.dismissButton)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.titleLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.descLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.viewsButton)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.retinaButton)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.mmlButton)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.playgroundsButton)
        }
        
        viewsButton.layer.cornerRadius = 20
        viewsButton.layer.masksToBounds = true
        viewsButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        viewsButton.addTarget(self, action: #selector(self.viewsNews), for: .touchUpInside)
        retinaButton.layer.cornerRadius = 20
        retinaButton.layer.masksToBounds = true
        retinaButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        retinaButton.addTarget(self, action: #selector(self.retina), for: .touchUpInside)
        mmlButton.layer.cornerRadius = 20
        mmlButton.layer.masksToBounds = true
        mmlButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        mmlButton.addTarget(self, action: #selector(self.mml), for: .touchUpInside)
        playgroundsButton.layer.cornerRadius = 20
        playgroundsButton.layer.masksToBounds = true
        playgroundsButton.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        playgroundsButton.addTarget(self, action: #selector(self.emojihunt), for: .touchUpInside)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.dismissButton.frame = CGRect(x: self.view.frame.midX - 150, y: self.view.frame.maxY - 68, width: 300, height: 60)
        self.titleLabel.frame = CGRect(x: 0, y: 8, width: self.view.frame.width, height: 60)
        self.descLabel.frame = CGRect(x: 8, y: self.titleLabel.frame.maxY, width:  self.view.frame.width - 16, height: 150)
        self.viewsButton.frame = CGRect(x: self.view.frame.midX - 158, y: self.descLabel.frame.maxY + 8, width: 150, height: 150)
        self.retinaButton.frame = CGRect(x: self.view.frame.midX + 8, y: self.descLabel.frame.maxY + 8, width: 150, height: 150)
        self.mmlButton.frame = CGRect(x: self.view.frame.midX - 158, y: self.viewsButton.frame.maxY + 8, width: 150, height: 150)
        self.playgroundsButton.frame = CGRect(x: self.view.frame.midX + 8, y: self.viewsButton.frame.maxY + 8, width: 150, height: 150)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.async {
            if UserDefaults.standard.bool(forKey: "darkModeOn") {
                let gradient = createGradient(colors: [#colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor, #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
                gradient.frame = self.view.bounds
                DispatchQueue.main.async {
                    self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
                }
                self.dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0)
                self.dismissButton.layer.shadowColor = #colorLiteral(red: 0.239215686917305, green: 0.6745098233222961, blue: 0.9686274528503418, alpha: 1.0).cgColor
                self.dismissButton.layer.shadowOpacity = 0.3
                self.dismissButton.layer.shadowRadius = 5
                self.dismissButton.layer.masksToBounds = false
            } else {
                let gradient = createGradient(colors: [#colorLiteral(red: 0.0, green: 0.776, blue: 0.984, alpha: 1).cgColor, #colorLiteral(red: 0.0, green: 0.357, blue: 0.918, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
                gradient.frame = self.view.bounds
                DispatchQueue.main.async {
                    self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
                }
                self.dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.0, green: 0.357, blue: 0.918, alpha: 1.0)
                self.dismissButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
                self.dismissButton.layer.shadowOpacity = 0.2
                self.dismissButton.layer.shadowRadius = 10
                self.dismissButton.layer.shadowOffset = CGSize(width: 0, height: 10)
                self.dismissButton.layer.masksToBounds = false
            }
        }
    }
    
    @objc func goBack() {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func viewsNews() {
        let vc = ViewsViewController()
        vc.modalPresentationStyle = .formSheet
        vc.modalTransitionStyle = .coverVertical
        self.present(vc, animated: true, completion: nil)
    }
    
    @objc func retina() {
        let vc = RetinaViewController()
        vc.modalPresentationStyle = .formSheet
        vc.modalTransitionStyle = .coverVertical
        self.present(vc, animated: true, completion: nil)
    }
    
    @objc func mml() {
        let vc = MMLViewController()
        vc.modalPresentationStyle = .formSheet
        vc.modalTransitionStyle = .coverVertical
        self.present(vc, animated: true, completion: nil)
    }
    
    @objc func emojihunt() {
        let vc = EmojiHuntViewController()
        vc.modalPresentationStyle = .formSheet
        vc.modalTransitionStyle = .coverVertical
        self.present(vc, animated: true, completion: nil)
    }
}

class ViewsViewController: UIViewController {
    let dismissButton = UIButton(frame: .zero)
    let logoImageView = UIImageView(frame: .zero)
    let titleLabel = UILabel(frame: .zero)
    let descLabel = createLabel(title: "The Views News is one of the best news apps for iOS, wathOS, and tvOS. This app was my first app and initially presented the latest headlines to you based on your interests. However, in this age of divisiveness, I wanted Views to be a platform where people can come to gether to talk about the news and have important discussions without fearing people ridiculing them for their views. You can download the app and try this out on the App Store!", textColor: .white, fontSize: 20, fontWeight: .medium, alignment: .center)
    
    override func loadView() {
        super.loadView()
        dismissButton.layer.cornerRadius = 10
        dismissButton.layer.masksToBounds = true
        dismissButton.backgroundColor = .white
        dismissButton.setTitle("Go Back!", for: .normal)
        dismissButton.titleLabel?.font = UIFont(name: "Phosphate-Solid", size: 24)
        dismissButton.addTarget(self, action: #selector(self.goBack), for: .touchUpInside)
        
        titleLabel.text = "The Views News"
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont(name: "Phosphate-Solid", size: 40)
        
        logoImageView.image = #imageLiteral(resourceName: "Views.png")
        
        DispatchQueue.main.async {
            self.view.addSubview(self.dismissButton)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.titleLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.descLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.logoImageView)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        logoImageView.frame = CGRect(x: self.view.frame.midX - 75, y: 8, width: 150, height: 150)
        titleLabel.frame = CGRect(x: 0, y: self.logoImageView.frame.maxY + 8, width: self.view.frame.width, height: 50)
        descLabel.frame = CGRect(x: 8, y: self.titleLabel.frame.maxY, width: self.view.frame.width - 16, height: 250)
        dismissButton.frame = CGRect(x: self.view.frame.midX - 150, y: self.view.frame.maxY - 68, width: 300, height: 60)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if UserDefaults.standard.bool(forKey: "darkModeOn") {
            let gradient = createGradient(colors: [#colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor, #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
            gradient.frame = self.view.bounds
            DispatchQueue.main.async {
                self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
            }
            dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0)
            dismissButton.layer.shadowColor = #colorLiteral(red: 0.5568627715110779, green: 0.3529411852359772, blue: 0.9686274528503418, alpha: 1.0).cgColor
            dismissButton.layer.shadowOpacity = 0.3
            dismissButton.layer.shadowRadius = 5
            dismissButton.layer.masksToBounds = false
        } else {
            let gradient = createGradient(colors: [#colorLiteral(red: 0.5568627715110779, green: 0.3529411852359772, blue: 0.9686274528503418, alpha: 1.0).cgColor, #colorLiteral(red: 0.21960784494876862, green: 0.007843137718737125, blue: 0.8549019694328308, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
            gradient.frame = self.view.bounds
            DispatchQueue.main.async {
                self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
            }
            dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.21960784494876862, green: 0.007843137718737125, blue: 0.8549019694328308, alpha: 1.0)
            dismissButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
            dismissButton.layer.shadowOpacity = 0.2
            dismissButton.layer.shadowRadius = 10
            dismissButton.layer.shadowOffset = CGSize(width: 0, height: 10)
            dismissButton.layer.masksToBounds = false
        }
    }
    
    @objc func goBack() {
        self.dismiss(animated: true, completion: nil)
    }
}

class RetinaViewController: UIViewController {
    let dismissButton = UIButton(frame: .zero)
    let logoImageView = UIImageView(frame: .zero)
    let titleLabel = UILabel(frame: .zero)
    let descLabel = createLabel(title: "In September 2018, I won Fritz's ML Grant- a $1000 grant for developing the app of your dreams as long as it uses machine learning. My idea was to build an app for visually impaired people which describes their surroundings to them. However, rather than a simple image recognizer, this app would use Tensorflow's Img2Txt model which describes scenes in stunning detail. Currently in progress, this app is sceduled for a release in May! Keep a lookout for this!", textColor: .white, fontSize: 20, fontWeight: .medium, alignment: .center)
    
    override func loadView() {
        super.loadView()
        dismissButton.layer.cornerRadius = 10
        dismissButton.layer.masksToBounds = true
        dismissButton.backgroundColor = .white
        dismissButton.setTitle("Go Back!", for: .normal)
        dismissButton.titleLabel?.font = UIFont(name: "Phosphate-Solid", size: 24)
        dismissButton.addTarget(self, action: #selector(self.goBack), for: .touchUpInside)
        
        titleLabel.text = "Retina AI"
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont(name: "Phosphate-Solid", size: 40)
        
        logoImageView.image = #imageLiteral(resourceName: "Retina.png")
        
        DispatchQueue.main.async {
            self.view.addSubview(self.dismissButton)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.titleLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.descLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.logoImageView)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        logoImageView.frame = CGRect(x: self.view.frame.midX - 75, y: 8, width: 150, height: 150)
        titleLabel.frame = CGRect(x: 0, y: self.logoImageView.frame.maxY + 8, width: self.view.frame.width, height: 50)
        descLabel.frame = CGRect(x: 8, y: self.titleLabel.frame.maxY, width: self.view.frame.width - 16, height: 250)
        dismissButton.frame = CGRect(x: self.view.frame.midX - 150, y: self.view.frame.maxY - 68, width: 300, height: 60)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if UserDefaults.standard.bool(forKey: "darkModeOn") {
            let gradient = createGradient(colors: [#colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor, #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
            gradient.frame = self.view.bounds
            DispatchQueue.main.async {
                self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
            }
            dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0)
            dismissButton.layer.shadowColor = #colorLiteral(red: 0.4745098054409027, green: 0.8392156958580017, blue: 0.9764705896377563, alpha: 1.0).cgColor
            dismissButton.layer.shadowOpacity = 0.3
            dismissButton.layer.shadowRadius = 5
            dismissButton.layer.masksToBounds = false
        } else {
            let gradient = createGradient(colors: [#colorLiteral(red: 0.4745098054409027, green: 0.8392156958580017, blue: 0.9764705896377563, alpha: 1.0).cgColor, #colorLiteral(red: 0.1764705926179886, green: 0.49803921580314636, blue: 0.7568627595901489, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
            gradient.frame = self.view.bounds
            DispatchQueue.main.async {
                self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
            }
            dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.1764705926179886, green: 0.49803921580314636, blue: 0.7568627595901489, alpha: 1.0)
            dismissButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
            dismissButton.layer.shadowOpacity = 0.2
            dismissButton.layer.shadowRadius = 10
            dismissButton.layer.shadowOffset = CGSize(width: 0, height: 10)
            dismissButton.layer.masksToBounds = false
        }
    }
    
    @objc func goBack() {
        self.dismiss(animated: true, completion: nil)
    }
}

class MMLViewController: UIViewController {
    let dismissButton = UIButton(frame: .zero)
    let logoImageView = UIImageView(frame: .zero)
    let titleLabel = UILabel(frame: .zero)
    let descLabel = createLabel(title: "Mastering Machine Learning for iOS is the first technical book I am authoring for the Apple developer community. After spending two years at AppCoda writing coding tutorials on machine learning, I always received questions from my readers. After a while, I began to notice the pattern in questions and wanted to do something about this. I decided to write a book covering everything machine learning related: from the basics to Core ML to Turi Create to Tensorflow for Swift. I'm done writing 25% of the book and can't wait to see what else I can add following WWDC 2019.", textColor: .white, fontSize: 20, fontWeight: .medium, alignment: .center)
    
    override func loadView() {
        super.loadView()
        dismissButton.layer.cornerRadius = 10
        dismissButton.layer.masksToBounds = true
        dismissButton.backgroundColor = .white
        dismissButton.setTitle("Go Back!", for: .normal)
        dismissButton.titleLabel?.font = UIFont(name: "Phosphate-Solid", size: 24)
        dismissButton.addTarget(self, action: #selector(self.goBack), for: .touchUpInside)
        
        titleLabel.text = "Mastering ML For iOS"
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont(name: "Phosphate-Solid", size: 40)
        
        logoImageView.image = #imageLiteral(resourceName: "Book.png")
        logoImageView.contentMode = .scaleAspectFit
        
        DispatchQueue.main.async {
            self.view.addSubview(self.dismissButton)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.titleLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.descLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.logoImageView)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        logoImageView.frame = CGRect(x: self.view.frame.midX - 75, y: 8, width: 150, height: 150)
        titleLabel.frame = CGRect(x: 0, y: self.logoImageView.frame.maxY + 8, width: self.view.frame.width, height: 50)
        descLabel.frame = CGRect(x: 8, y: self.titleLabel.frame.maxY, width: self.view.frame.width - 16, height: 300)
        dismissButton.frame = CGRect(x: self.view.frame.midX - 150, y: self.view.frame.maxY - 68, width: 300, height: 60)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if UserDefaults.standard.bool(forKey: "darkModeOn") {
            let gradient = createGradient(colors: [#colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor, #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
            gradient.frame = self.view.bounds
            DispatchQueue.main.async {
                self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
            }
            dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0)
            dismissButton.layer.shadowColor = #colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0).cgColor
            dismissButton.layer.shadowOpacity = 0.3
            dismissButton.layer.shadowRadius = 5
            dismissButton.layer.masksToBounds = false
        } else {
            let gradient = createGradient(colors: [#colorLiteral(red: 0.9098039269447327, green: 0.47843137383461, blue: 0.6431372761726379, alpha: 1.0).cgColor, #colorLiteral(red: 0.8078431487083435, green: 0.027450980618596077, blue: 0.3333333432674408, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
            gradient.frame = self.view.bounds
            DispatchQueue.main.async {
                self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
            }
            dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.8078431487083435, green: 0.027450980618596077, blue: 0.3333333432674408, alpha: 1.0)
            dismissButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
            dismissButton.layer.shadowOpacity = 0.2
            dismissButton.layer.shadowRadius = 10
            dismissButton.layer.shadowOffset = CGSize(width: 0, height: 10)
            dismissButton.layer.masksToBounds = false
        }
    }
    
    @objc func goBack() {
        self.dismiss(animated: true, completion: nil)
    }
}

class EmojiHuntViewController: UIViewController {
    let dismissButton = UIButton(frame: .zero)
    let logoImageView = UIImageView(frame: .zero)
    let titleLabel = UILabel(frame: .zero)
    let descLabel = createLabel(title: "Emoji Hunt is the playground you're looking at right now! I've always felt that machine learning has been making excellent strides in helping humans but not so much on the entertainment front. This is why I decided to take the WWDC 2019 scholarship as an opportunity to blow some minds. Using Core ML and ARKit, I wanted to make a game that lets us look at our screens while being aware of our surroundings, in an effort to be more connected with our environment. Thus, came Emoji Hunt! A seamless integration of old and new technology, I hope you enjoy this game!", textColor: .white, fontSize: 20, fontWeight: .medium, alignment: .center)
    
    override func loadView() {
        super.loadView()
        dismissButton.layer.cornerRadius = 10
        dismissButton.layer.masksToBounds = true
        dismissButton.backgroundColor = .white
        dismissButton.setTitle("Go Back!", for: .normal)
        dismissButton.titleLabel?.font = UIFont(name: "Phosphate-Solid", size: 24)
        dismissButton.addTarget(self, action: #selector(self.goBack), for: .touchUpInside)
        
        titleLabel.text = "Emoji Hunt"
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont(name: "Phosphate-Solid", size: 40)
        
        logoImageView.image = #imageLiteral(resourceName: "Artboard.png")
        
        DispatchQueue.main.async {
            self.view.addSubview(self.dismissButton)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.titleLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.descLabel)
        }
        DispatchQueue.main.async {
            self.view.addSubview(self.logoImageView)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        logoImageView.frame = CGRect(x: self.view.frame.midX - 75, y: 8, width: 150, height: 150)
        titleLabel.frame = CGRect(x: 0, y: self.logoImageView.frame.maxY + 8, width: self.view.frame.width, height: 50)
        descLabel.frame = CGRect(x: 8, y: self.titleLabel.frame.maxY, width: self.view.frame.width - 16, height: 300)
        dismissButton.frame = CGRect(x: self.view.frame.midX - 150, y: self.view.frame.maxY - 68, width: 300, height: 60)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if UserDefaults.standard.bool(forKey: "darkModeOn") {
            let gradient = createGradient(colors: [#colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor, #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
            gradient.frame = self.view.bounds
            DispatchQueue.main.async {
                self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
            }
            dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.118, green: 0.141, blue: 0.282, alpha: 1.0)
            dismissButton.layer.shadowColor = #colorLiteral(red: 0.9411764740943909, green: 0.49803921580314636, blue: 0.3529411852359772, alpha: 1.0).cgColor
            dismissButton.layer.shadowOpacity = 0.3
            dismissButton.layer.shadowRadius = 5
            dismissButton.layer.masksToBounds = false
        } else {
            let gradient = createGradient(colors: [#colorLiteral(red: 0.9411764740943909, green: 0.49803921580314636, blue: 0.3529411852359772, alpha: 1.0).cgColor, #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0).cgColor], startPoint: CGPoint(x: 0.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
            gradient.frame = self.view.bounds
            DispatchQueue.main.async {
                self.view.layer.insertSublayer(gradient, below: self.dismissButton.layer)
            }
            dismissButton.titleLabel?.textColor = #colorLiteral(red: 0.9254902005195618, green: 0.23529411852359772, blue: 0.10196078568696976, alpha: 1.0)
            dismissButton.layer.shadowColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0).cgColor
            dismissButton.layer.shadowOpacity = 0.2
            dismissButton.layer.shadowRadius = 10
            dismissButton.layer.shadowOffset = CGSize(width: 0, height: 10)
            dismissButton.layer.masksToBounds = false
        }
    }
    
    @objc func goBack() {
        self.dismiss(animated: true, completion: nil)
    }
}

extension ARSCNView {
    func setup() {
        antialiasingMode = .multisampling4X
        automaticallyUpdatesLighting = false
        
        preferredFramesPerSecond = 60
        contentScaleFactor = 1.0
        
        if let camera = pointOfView?.camera {
            camera.wantsHDR = true
            camera.wantsExposureAdaptation = true
            camera.exposureOffset = 0
            camera.minimumExposure = 0
            camera.maximumExposure = 2
            camera.focusDistance = 0.5
        }
    }
}

// MARK:- Create Functions
func createLabel(title: String, textColor: UIColor, fontSize: CGFloat, fontWeight: UIFont.Weight, alignment: NSTextAlignment) -> UILabel {
    let label = UILabel()
    label.text = title
    label.textColor = textColor
    label.font = UIFont.systemFont(ofSize: fontSize, weight: fontWeight)
    label.textAlignment = alignment
    label.numberOfLines = 0
    return label
}

func createTitle(title: String, textColor: UIColor, fontSize: CGFloat, alignment: NSTextAlignment, solid: Bool) -> UILabel {
    let label = UILabel()
    label.text = title
    label.textColor = textColor
    
    let fontURL = Bundle.main.url(forResource: "Phosphate", withExtension: "ttc")
    CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
    if solid == true {
        label.font = UIFont(name: "Phosphate-Solid", size: fontSize)
    } else {
        label.font = UIFont(name: "Phosphate-Inline", size: fontSize)
    }
    label.textAlignment = alignment
    return label
}

func createGradient(colors: [CGColor], startPoint: CGPoint, endPoint: CGPoint) -> CAGradientLayer {
    let gradient = CAGradientLayer()
    gradient.colors = colors
    gradient.startPoint = startPoint
    gradient.endPoint = endPoint
    return gradient
}

func createButton(title: String, bgColor: UIColor, fontColor: UIColor) -> UIButton {
    let button = UIButton(frame: .zero)
    button.showsTouchWhenHighlighted = true
    button.setTitle(title, for: .normal)
    button.alpha = 1.0
    button.backgroundColor = bgColor
    let fontURL = Bundle.main.url(forResource: "Phosphate", withExtension: "ttc")
    CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
    button.titleLabel?.font = UIFont(name: "Phosphate-Solid", size: 24)
    button.titleLabel?.textAlignment = .center
    button.titleLabel?.numberOfLines = 0
    button.setTitleColor(fontColor, for: .normal)
    return button
}

func createView(bgColor: UIColor) -> UIView {
    let view = UIView()
    view.backgroundColor = bgColor
    return view
}

func createImageView() -> UIImageView {
    let imageView = UIImageView(frame: .zero)
    imageView.image = #imageLiteral(resourceName: "AI Olympics Logo.png")
    imageView.contentMode = .scaleAspectFit
    return imageView
}

// MARK:- Helper Functions
func randomInt(min: Int, max: Int) -> Int {
    return Int(arc4random_uniform(UInt32(max-(min-1)))) + min
}

// MARK:- Gender Recognizer
/// Model Prediction Input Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class GenderClassifierInput : MLFeatureProvider {
    
    /// Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 299 pixels wide by 299 pixels high
    var image: CVPixelBuffer
    
    var featureNames: Set<String> {
        get {
            return ["image"]
        }
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "image") {
            return MLFeatureValue(pixelBuffer: image)
        }
        return nil
    }
    
    init(image: CVPixelBuffer) {
        self.image = image
    }
}

/// Model Prediction Output Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class GenderClassifierOutput : MLFeatureProvider {
    
    /// Source provided by CoreML
    
    private let provider : MLFeatureProvider
    
    
    /// Probability of each category as dictionary of strings to doubles
    lazy var classLabelProbs: [String : Double] = {
        [unowned self] in return self.provider.featureValue(for: "classLabelProbs")!.dictionaryValue as! [String : Double]
        }()
    
    /// Most likely image category as string value
    lazy var classLabel: String = {
        [unowned self] in return self.provider.featureValue(for: "classLabel")!.stringValue
        }()
    
    var featureNames: Set<String> {
        return self.provider.featureNames
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        return self.provider.featureValue(for: featureName)
    }
    
    init(classLabelProbs: [String : Double], classLabel: String) {
        self.provider = try! MLDictionaryFeatureProvider(dictionary: ["classLabelProbs" : MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber]), "classLabel" : MLFeatureValue(string: classLabel)])
    }
    
    init(features: MLFeatureProvider) {
        self.provider = features
    }
}


/// Class for model loading and prediction
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class GenderClassifier {
    var model: MLModel
    
    /// URL of model assuming it was installed in the same bundle as this class
    class var urlOfModelInThisBundle : URL {
        let bundle = Bundle(for: GenderClassifier.self)
        return bundle.url(forResource: "GenderClassifier", withExtension:"mlmodelc")!
    }
    
    /**
     Construct a model with explicit path to mlmodelc file
     - parameters:
     - url: the file url of the model
     - throws: an NSError object that describes the problem
     */
    init(contentsOf url: URL) throws {
        self.model = try MLModel(contentsOf: url)
    }
    
    /// Construct a model that automatically loads the model from the app's bundle
    convenience init() {
        try! self.init(contentsOf: type(of:self).urlOfModelInThisBundle)
    }
    
    /**
     Construct a model with configuration
     - parameters:
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    convenience init(configuration: MLModelConfiguration) throws {
        try self.init(contentsOf: type(of:self).urlOfModelInThisBundle, configuration: configuration)
    }
    
    /**
     Construct a model with explicit path to mlmodelc file and configuration
     - parameters:
     - url: the file url of the model
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    init(contentsOf url: URL, configuration: MLModelConfiguration) throws {
        self.model = try MLModel(contentsOf: url, configuration: configuration)
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as GenderClassifierInput
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as GenderClassifierOutput
     */
    func prediction(input: GenderClassifierInput) throws -> GenderClassifierOutput {
        return try self.prediction(input: input, options: MLPredictionOptions())
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as GenderClassifierInput
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as GenderClassifierOutput
     */
    func prediction(input: GenderClassifierInput, options: MLPredictionOptions) throws -> GenderClassifierOutput {
        let outFeatures = try model.prediction(from: input, options:options)
        return GenderClassifierOutput(features: outFeatures)
    }
    
    /**
     Make a prediction using the convenience interface
     - parameters:
     - image: Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 299 pixels wide by 299 pixels high
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as GenderClassifierOutput
     */
    func prediction(image: CVPixelBuffer) throws -> GenderClassifierOutput {
        let input_ = GenderClassifierInput(image: image)
        return try self.prediction(input: input_)
    }
    
    /**
     Make a batch prediction using the structured interface
     - parameters:
     - inputs: the inputs to the prediction as [GenderClassifierInput]
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as [GenderClassifierOutput]
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    func predictions(inputs: [GenderClassifierInput], options: MLPredictionOptions = MLPredictionOptions()) throws -> [GenderClassifierOutput] {
        let batchIn = MLArrayBatchProvider(array: inputs)
        let batchOut = try model.predictions(from: batchIn, options: options)
        var results : [GenderClassifierOutput] = []
        results.reserveCapacity(inputs.count)
        for i in 0..<batchOut.count {
            let outProvider = batchOut.features(at: i)
            let result =  GenderClassifierOutput(features: outProvider)
            results.append(result)
        }
        return results
    }
}

// MARK:- Emoji Recognition
/// Model Prediction Input Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class EmojiIRLInput : MLFeatureProvider {
    
    /// Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 299 pixels wide by 299 pixels high
    var image: CVPixelBuffer
    
    var featureNames: Set<String> {
        get {
            return ["image"]
        }
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "image") {
            return MLFeatureValue(pixelBuffer: image)
        }
        return nil
    }
    
    init(image: CVPixelBuffer) {
        self.image = image
    }
}

/// Model Prediction Output Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class EmojiIRLOutput : MLFeatureProvider {
    
    /// Source provided by CoreML
    
    private let provider : MLFeatureProvider
    
    
    /// Probability of each category as dictionary of strings to doubles
    lazy var classLabelProbs: [String : Double] = {
        [unowned self] in return self.provider.featureValue(for: "classLabelProbs")!.dictionaryValue as! [String : Double]
        }()
    
    /// Most likely image category as string value
    lazy var classLabel: String = {
        [unowned self] in return self.provider.featureValue(for: "classLabel")!.stringValue
        }()
    
    var featureNames: Set<String> {
        return self.provider.featureNames
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        return self.provider.featureValue(for: featureName)
    }
    
    init(classLabelProbs: [String : Double], classLabel: String) {
        self.provider = try! MLDictionaryFeatureProvider(dictionary: ["classLabelProbs" : MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber]), "classLabel" : MLFeatureValue(string: classLabel)])
    }
    
    init(features: MLFeatureProvider) {
        self.provider = features
    }
}


/// Class for model loading and prediction
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class EmojiIRL {
    var model: MLModel
    
    /// URL of model assuming it was installed in the same bundle as this class
    class var urlOfModelInThisBundle : URL {
        let bundle = Bundle(for: EmojiIRL.self)
        return bundle.url(forResource: "EmojiIRL", withExtension:"mlmodelc")!
    }
    
    /**
     Construct a model with explicit path to mlmodelc file
     - parameters:
     - url: the file url of the model
     - throws: an NSError object that describes the problem
     */
    init(contentsOf url: URL) throws {
        self.model = try MLModel(contentsOf: url)
    }
    
    /// Construct a model that automatically loads the model from the app's bundle
    convenience init() {
        try! self.init(contentsOf: type(of:self).urlOfModelInThisBundle)
    }
    
    /**
     Construct a model with configuration
     - parameters:
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    convenience init(configuration: MLModelConfiguration) throws {
        try self.init(contentsOf: type(of:self).urlOfModelInThisBundle, configuration: configuration)
    }
    
    /**
     Construct a model with explicit path to mlmodelc file and configuration
     - parameters:
     - url: the file url of the model
     - configuration: the desired model configuration
     - throws: an NSError object that describes the problem
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    init(contentsOf url: URL, configuration: MLModelConfiguration) throws {
        self.model = try MLModel(contentsOf: url, configuration: configuration)
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as EmojiIRLInput
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as EmojiIRLOutput
     */
    func prediction(input: EmojiIRLInput) throws -> EmojiIRLOutput {
        return try self.prediction(input: input, options: MLPredictionOptions())
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as EmojiIRLInput
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as EmojiIRLOutput
     */
    func prediction(input: EmojiIRLInput, options: MLPredictionOptions) throws -> EmojiIRLOutput {
        let outFeatures = try model.prediction(from: input, options:options)
        return EmojiIRLOutput(features: outFeatures)
    }
    
    /**
     Make a prediction using the convenience interface
     - parameters:
     - image: Input image to be classified as color (kCVPixelFormatType_32BGRA) image buffer, 299 pixels wide by 299 pixels high
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as EmojiIRLOutput
     */
    func prediction(image: CVPixelBuffer) throws -> EmojiIRLOutput {
        let input_ = EmojiIRLInput(image: image)
        return try self.prediction(input: input_)
    }
    
    /**
     Make a batch prediction using the structured interface
     - parameters:
     - inputs: the inputs to the prediction as [EmojiIRLInput]
     - options: prediction options
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as [EmojiIRLOutput]
     */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    func predictions(inputs: [EmojiIRLInput], options: MLPredictionOptions = MLPredictionOptions()) throws -> [EmojiIRLOutput] {
        let batchIn = MLArrayBatchProvider(array: inputs)
        let batchOut = try model.predictions(from: batchIn, options: options)
        var results : [EmojiIRLOutput] = []
        results.reserveCapacity(inputs.count)
        for i in 0..<batchOut.count {
            let outProvider = batchOut.features(at: i)
            let result =  EmojiIRLOutput(features: outProvider)
            results.append(result)
        }
        return results
    }
}

PlaygroundPage.current.liveView = HomeViewController()
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.wantsFullScreenLiveView = true
//#-end-hidden-code
